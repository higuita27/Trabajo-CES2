package org.example.ces21.modelos;

public class Exploracion {
    private final String nave;
    private final int anio;
    private final int duracionEnDias;

    public Exploracion(String nave, int anio, int duracionEnDias) {
        this.nave = nave;
        this.anio = anio;
        this.duracionEnDias = duracionEnDias;
    }

    public String obtenerNave() { return nave; }
    public int obtenerAnio() { return anio; }
    public int obtenerDuracionEnDias() { return duracionEnDias; }
}
