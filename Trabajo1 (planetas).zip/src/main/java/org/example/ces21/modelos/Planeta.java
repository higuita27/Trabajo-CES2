package org.example.ces21.modelos;

import java.util.ArrayList;
import java.util.List;

public class Planeta {
    private final String nombre;
    private final String galaxia;
    private final double tamanioKm;
    private final boolean tieneVida;
    private final List<Exploracion> exploraciones = new ArrayList<>();

    public Planeta(String nombre, String galaxia, double tamanioKm, boolean tieneVida) {
        this.nombre = nombre;
        this.galaxia = galaxia;
        this.tamanioKm = tamanioKm;
        this.tieneVida = tieneVida;
    }

    public String obtenerNombre() { return nombre; }
    public String obtenerGalaxia() { return galaxia; }
    public double obtenerTamanioKm() { return tamanioKm; }
    public boolean tieneVida() { return tieneVida; }
    public List<Exploracion> obtenerExploraciones() { return exploraciones; }

    public void agregarExploracion(Exploracion e) {
        exploraciones.add(e);
    }
}
