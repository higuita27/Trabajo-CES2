package org.example.ces21;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AplicacionCes21 {
    public static void main(String[] args) {
        SpringApplication.run(AplicacionCes21.class, args);
    }
}
