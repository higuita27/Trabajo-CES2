package org.example.ces21.controladores;

import org.example.ces21.modelos.Planeta;
import org.example.ces21.modelos.Exploracion;
import org.example.ces21.repositorios.PlanetaRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Controller
public class PlanetaControlador {

    @Autowired
    private PlanetaRepositorio repositorio;

    @GetMapping("/vista1")
    public String vista1(Model modelo) {
        String nombres = repositorio.obtenerPlanetas()
                .stream()
                .map(Planeta::obtenerNombre)
                .collect(Collectors.joining(", "));
        modelo.addAttribute("nombres", nombres);
        return "vista1";
    }

    @GetMapping("/vista2")
    public String vista2(Model modelo) {
        List<Exploracion> exploraciones = repositorio.obtenerPlanetas()
                .stream()
                .flatMap(p -> p.obtenerExploraciones().stream())
                .toList();

        long conteo = exploraciones.size();
        int suma = exploraciones.stream().mapToInt(Exploracion::obtenerDuracionEnDias).sum();
        double promedio = exploraciones.stream().mapToInt(Exploracion::obtenerDuracionEnDias).average().orElse(0);
        int minimo = exploraciones.stream().mapToInt(Exploracion::obtenerDuracionEnDias).min().orElse(0);
        int maximo = exploraciones.stream().mapToInt(Exploracion::obtenerDuracionEnDias).max().orElse(0);

        modelo.addAttribute("conteo", conteo);
        modelo.addAttribute("suma", suma);
        modelo.addAttribute("promedio", promedio);
        modelo.addAttribute("minimo", minimo);
        modelo.addAttribute("maximo", maximo);

        return "vista2";
    }

    @GetMapping("/vista3")
    public String vista3(Model modelo) {
        List<String> naves = repositorio.obtenerPlanetas()
                .stream()
                .flatMap(p -> p.obtenerExploraciones().stream())
                .map(Exploracion::obtenerNave)
                .toList();

        modelo.addAttribute("naves", naves);
        return "vista3";
    }

    @GetMapping("/vista4")
    public String vista4(Model modelo) {
        boolean sinExploraciones = repositorio.obtenerPlanetas().stream().anyMatch(p -> p.obtenerExploraciones().isEmpty());
        boolean masDeDos = repositorio.obtenerPlanetas().stream().anyMatch(p -> p.obtenerExploraciones().size() > 2);
        boolean ningunoMasDeCinco = repositorio.obtenerPlanetas().stream().noneMatch(p -> p.obtenerExploraciones().size() > 5);

        modelo.addAttribute("sinExploraciones", sinExploraciones);
        modelo.addAttribute("masDeDos", masDeDos);
        modelo.addAttribute("ningunoMasDeCinco", ningunoMasDeCinco);

        return "vista4";
    }

    @GetMapping("/vista5")
    public String vista5(Model modelo) {
        List<Exploracion> exploraciones = repositorio.obtenerPlanetas()
                .stream()
                .flatMap(p -> p.obtenerExploraciones().stream())
                .toList();

        Exploracion mayor = exploraciones.stream()
                .max(Comparator.comparingInt(Exploracion::obtenerDuracionEnDias))
                .orElse(null);

        modelo.addAttribute("mayor", mayor);
        return "vista5";
    }
}
