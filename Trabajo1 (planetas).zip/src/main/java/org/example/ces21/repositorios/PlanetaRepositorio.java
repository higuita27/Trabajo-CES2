package org.example.ces21.repositorios;

import org.example.ces21.modelos.Planeta;
import org.example.ces21.modelos.Exploracion;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class PlanetaRepositorio {
    private final List<Planeta> planetas = new ArrayList<>();

    public PlanetaRepositorio() {
        for (int i = 1; i <= 20; i++) {
            Planeta p = new Planeta("Planeta" + i, "Galaxia-" + (i % 3 + 1), 5000 * i, i % 2 == 0);
            if (i % 2 == 0) {
                p.agregarExploracion(new Exploracion("Nave-" + i, 2000 + i, 10 + i));
                p.agregarExploracion(new Exploracion("Sonda-" + i, 1990 + i, 5 + i));
            }
            if (i % 5 == 0) {
                p.agregarExploracion(new Exploracion("Mision-" + i, 2010 + i, 20 + i));
            }
            planetas.add(p);
        }
    }

    public List<Planeta> obtenerPlanetas() {
        return planetas;
    }
}
