package org.example.ces21;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ces21Application {
    public static void main(String[] args) {
        SpringApplication.run(Ces21Application.class, args);
    }
}
