package org.example.ces21.repositories;

import org.example.ces21.models.Planeta;
import org.example.ces21.models.Exploracion;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class PlanetaRepository {
    private List<Planeta> planetas = new ArrayList<>();

    public PlanetaRepository() {
        for (int i = 1; i <= 20; i++) {
            Planeta p = new Planeta("Planeta" + i, "Galaxia-" + (i % 3 + 1), 1000 * i, i % 2 == 0);
            if (i % 2 == 0) {
                p.agregarExploracion(new Exploracion("NaveX-" + i, 2000 + i, 50 + i));
                p.agregarExploracion(new Exploracion("NaveY-" + i, 2010 + i, 70 + i));
            }
            if (i % 5 == 0) {
                p.agregarExploracion(new Exploracion("NaveZ-" + i, 2020 + i, 120 + i));
            }
            planetas.add(p);
        }
    }

    public List<Planeta> getPlanetas() {
        return planetas;
    }
}
