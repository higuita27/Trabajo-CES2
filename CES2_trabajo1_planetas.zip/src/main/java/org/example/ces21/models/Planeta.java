package org.example.ces21.models;

import java.util.ArrayList;
import java.util.List;

public class Planeta {
    private String nombre;
    private String galaxia;
    private double tamanoKm;
    private boolean tieneVida;
    private List<Exploracion> exploraciones = new ArrayList<>();

    public Planeta(String nombre, String galaxia, double tamanoKm, boolean tieneVida) {
        this.nombre = nombre;
        this.galaxia = galaxia;
        this.tamanoKm = tamanoKm;
        this.tieneVida = tieneVida;
    }

    public String getNombre() { return nombre; }
    public String getGalaxia() { return galaxia; }
    public double getTamanoKm() { return tamanoKm; }
    public boolean isTieneVida() { return tieneVida; }
    public List<Exploracion> getExploraciones() { return exploraciones; }

    public void agregarExploracion(Exploracion e) {
        exploraciones.add(e);
    }
}
