package org.example.ces21.models;

public class Exploracion {
    private String nave;
    private int anio;
    private int duracionDias;

    public Exploracion(String nave, int anio, int duracionDias) {
        this.nave = nave;
        this.anio = anio;
        this.duracionDias = duracionDias;
    }

    public String getNave() { return nave; }
    public int getAnio() { return anio; }
    public int getDuracionDias() { return duracionDias; }
}
