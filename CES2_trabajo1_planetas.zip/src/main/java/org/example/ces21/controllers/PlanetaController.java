package org.example.ces21.controllers;

import org.example.ces21.models.Exploracion;
import org.example.ces21.models.Planeta;
import org.example.ces21.repositories.PlanetaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Controller
public class PlanetaController {

    @Autowired
    private PlanetaRepository repository;

    @GetMapping("/vista1")
    public String vista1(Model model) {
        String nombres = repository.getPlanetas()
                .stream()
                .map(Planeta::getNombre)
                .collect(Collectors.joining(", "));
        model.addAttribute("nombres", nombres);
        return "vista1";
    }

    @GetMapping("/vista2")
    public String vista2(Model model) {
        List<Exploracion> exploraciones = repository.getPlanetas()
                .stream()
                .flatMap(p -> p.getExploraciones().stream())
                .toList();

        long conteo = exploraciones.size();
        int suma = exploraciones.stream().mapToInt(Exploracion::getDuracionDias).sum();
        double promedio = exploraciones.stream().mapToInt(Exploracion::getDuracionDias).average().orElse(0);
        int min = exploraciones.stream().mapToInt(Exploracion::getDuracionDias).min().orElse(0);
        int max = exploraciones.stream().mapToInt(Exploracion::getDuracionDias).max().orElse(0);

        model.addAttribute("conteo", conteo);
        model.addAttribute("suma", suma);
        model.addAttribute("promedio", promedio);
        model.addAttribute("min", min);
        model.addAttribute("max", max);

        return "vista2";
    }

    @GetMapping("/vista3")
    public String vista3(Model model) {
        List<String> naves = repository.getPlanetas()
                .stream()
                .flatMap(p -> p.getExploraciones().stream())
                .map(Exploracion::getNave)
                .toList();

        model.addAttribute("naves", naves);
        return "vista3";
    }

    @GetMapping("/vista4")
    public String vista4(Model model) {
        boolean sinExploraciones = repository.getPlanetas().stream().anyMatch(p -> p.getExploraciones().isEmpty());
        boolean masDeDos = repository.getPlanetas().stream().anyMatch(p -> p.getExploraciones().size() > 2);
        boolean ningunoMasDeCinco = repository.getPlanetas().stream().noneMatch(p -> p.getExploraciones().size() > 5);

        model.addAttribute("sinExploraciones", sinExploraciones);
        model.addAttribute("masDeDos", masDeDos);
        model.addAttribute("ningunoMasDeCinco", ningunoMasDeCinco);

        return "vista4";
    }

    @GetMapping("/vista5")
    public String vista5(Model model) {
        List<Exploracion> exploraciones = repository.getPlanetas()
                .stream()
                .flatMap(p -> p.getExploraciones().stream())
                .toList();

        Exploracion mayor = exploraciones.stream()
                .max(Comparator.comparingInt(Exploracion::getDuracionDias))
                .orElse(null);

        model.addAttribute("mayor", mayor);
        return "vista5";
    }
}
